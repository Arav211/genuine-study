import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export const gemini = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;
export const openai = OPENAI_API_KEY ? new OpenAI({ apiKey: OPENAI_API_KEY, dangerouslyAllowBrowser: true }) : null;

export const MODELS = {
  gemini: "gemini-3-flash-preview",
  openai: "gpt-4o-mini",
};

/**
 * Universal Generate Content
 * Tries Gemini first, falls back to OpenAI if Gemini fails or is missing.
 */
async function getAIResponse(prompt: string, options: { json?: boolean; system?: string } = {}) {
  if (gemini) {
    try {
      const response = await gemini.models.generateContent({
        model: MODELS.gemini,
        contents: prompt,
        config: {
          systemInstruction: options.system,
          responseMimeType: options.json ? "application/json" : "text/plain"
        }
      });
      return response.text || "";
    } catch (err) {
      console.error("Gemini failed, trying OpenAI if available...", err);
      if (!openai) throw err;
    }
  }

  if (openai) {
    const response = await openai.chat.completions.create({
      model: MODELS.openai,
      messages: [
        ...(options.system ? [{ role: "system" as const, content: options.system }] : []),
        { role: "user" as const, content: prompt }
      ],
      response_format: options.json ? { type: "json_object" } : undefined
    });
    return response.choices[0].message.content || "";
  }

  throw new Error("AI not initialized. Please configure Gemini or OpenAI API key in settings.");
}

export async function generateStudyPlan(topic: string) {
  const prompt = `Generate a detailed study plan for: ${topic}. Format as a JSON array of objects with 'title' and 'description'.`;
  const response = await getAIResponse(prompt, { json: true });
  try {
    return JSON.parse(response);
  } catch {
    return [];
  }
}

export async function explainConcept(concept: string, level: "eli5" | "standard" | "expert" = "standard") {
  const instruction = level === "eli5" ? "Explain like I'm 5." : level === "expert" ? "Explain at a university level with technical details." : "Explain clearly and concisely.";
  return getAIResponse(`${instruction} Concept: ${concept}`);
}

export async function generateFlashcards(text: string) {
  const prompt = `Generate 5 flashcards from this text: "${text}". Return a JSON array of objects with 'question' and 'answer' fields.`;
  const response = await getAIResponse(prompt, { json: true });
  try {
    return JSON.parse(response);
  } catch {
    return [];
  }
}
